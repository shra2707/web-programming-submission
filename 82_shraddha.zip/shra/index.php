<!DOCTYPE html>
<html>
<head>
<script>
function valid()
{
var x=document.myform.fn.value;
if(x==""){
alert("Please enter text only");
return false;
}
if(!isNan(x))
{
alert("Please enter text only");
return false;
}
if(!isNan(x))
{
alert("Please enter text only");
return false;
}
function contactnumber(inputtxt))
{
var phoneno = /^\d{10}$/;  
if((inputtxt.value.match(contactno))  
        {  
      return true;  
        }  
      else  
        {  
        alert("message");  
        return false;  
        }  
}  
function validateForm() {
    var x = document.forms["myForm"]["email"].value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        alert("Not a valid e-mail address");
        return false;
}
function ValidateForm(form){
ErrorText= "";
if ( ( form.gender[0].checked == false ) && ( form.gender[1].checked == false ) )
{
alert ( "Please choose your Gender: Male or Female" );
return false;
}
if (ErrorText= "") { form.submit() }
}
function validateDOB()
{
    var dob = document.forms["ProcessInfo"]["txtDOB"].value;
    var pattern = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
    if (dob == null || dob == "" || !pattern.test(dob)) {
        errMessage += "Invalid date of birth\n";
        return false;
    }
    else {
        return true
    }
function validation()
{
var a = document.form.address.value;
if(a=="")
{
alert("Please Enter Your Details Here");
document.form.address.focus();
return false;
}
}

</script>
<title>Univeristy of Mumbai form</title>
	
</head>
<body>

<style>
div{
margin-left:30%;
margin-right:30%;
}

body
 th,td{
border:1px solid black;
}

h1{
font-family: Old English Text MT;
}

th{
text-align:left;
}



}

</style>

<table width=100%>
<tr>
<img src="logo.png" alt="HTML5 Icon">
<div><td><h1><center>University of Mumbai</center><br>
<center>ABC College of Arts,Sci&Com<center></h1></td></div>
</tr>
</table>

<hr>

<div>
<form action="insert.php" name="myform" onsubmit="return valid()" method="post">
<fieldset>
<legend>Personal Information</legend>
<table bgcolor="white">

<tr>
<th>First name</th>
<td>:</td>
<td><input type="text" name="fn" onkeyup="limit(this,5);" onkeydown="limit(this)" value="" ></td>
</tr>

<tr>
<th>Middle name:</th>
<td>:</td>
<td><input type="text" name="mn"  /></td>
</tr>

<tr>
<th>Last name:</th>
<td>:</td>
<td><input type="text" name="ln"/></td>
</tr>

<tr>
<th>Mother's name:</th>
<td>:</td>
<td><input type="text" name="msn"/></td>
</tr>

<tr>
<th>Contact No.</th>
<td>:</td>
<td><input type="number" name="pn"  onkeyup="limit(this,10);"></td>
</tr>

<tr>
<th>Email Id:</th>
<td>:</td>
<td><input type="email" name="em" /></td>
</tr>

<tr>
<th>Gender</th>
<td>:</td>
<td><input type="radio" name="gen1" value="f">Female
    <input type="radio" name="gen1" value="m">Male
</td>
</tr>

<tr>
<th>DOB:</th>
<td>:</td>
<td><input type="date" name="bday"></td>
</tr>



</table>

<fieldset>
<legend>Address Details</legend>
<table bgcolor="white">
<tr>
<th>Address</th>
<td>:</td>
<td><textarea rows="5" cols="50" name="addr" /></textarea></td>
</tr>

<tr>
<th>Pincode</th>
<td>:</td>
<td><input type="number" name="pin" pattern="" /></td>
</tr>



<tr>
<th>Division</th>
<td>:</td>
<td>
<select name="divi">

<option value="MU">Mumbai</option>
<option value="ND">Nanded</option>
<option value="NG">Nagpur</option>
<option value="NS">Nashik</option>
<option value="PU">Pune</option>


</select></td>
</tr>

<tr>
<th>District</th>
<td>:</td>
<td><select name="dist">

<option value="ah">ahmednagar</option>
<option value="ak">akola</option>
<option value="am">amravati</option>
<option value="au">aurangabad</option>
<option value="bi">beed</option>
<option value="bh">bhandara</option>
<option value="bu">buldhana</option>
<option value="ch">chandrapur</option>
<option value="dh">dhule</option>
<option value="ga">gadchiroli</option>
<option value="go">gondia</option>
<option value="hi">hingoli</option>
<option value="jg">jalgaon</option>
<option value="jn">jalna</option>
<option value="ko">kolhapur</option>
<option value="la">latur</option>
<option value="mc">mumbai city</option>
<option value="mu">mumbai suburban</option>
<option value="ng">nagpur</option>
<option value="nd">nanded</option>
<option value="nb">nandurbar</option>
<option value="ns">nashik</option>
<option value="os">osmanabad</option>
<option value="pa">parbhani</option>
<option value="pu">pune</option>
<option value="rg">raigad</option>
<option value="rt">ratnagiri</option>
<option value="sn">sangli</option>
<option value="st">satara</option>
<option value="si">sindhudurg</option>
<option value="so">solapur</option>
<option value="th">thane</option>
<option value="wr">wardha</option>
<option value="as">washim</option>
<option value="ytl">yavatmal</option>
<option value="pl">palghar</option>

</select></td>
</tr>

<tr>
<th>Nationality</th>
<td>:</td>
<td><input type="radio" name="n" value="ind">Indian
    <input type="radio" name="n" value="other">Other
</td>
</tr>
</table>
</fieldset>


<fieldset>
<legend>College Details</legend>
<table bgcolor="white">

<tr>
<th>Name of college:</th>
<td>:</td>
<td><textarea rows="5" cols="50" name="nc"/>Enter name of college here</textarea></td>
</tr>

<tr>
<th> College Address:</th>
<td>:</td>
<td><textarea rows="5" cols="50" name="ca"/>Enter address here</textarea></td>
</tr>

<tr>
<th>Pincode:</th>
<td>:</td>
<td><input type="number" name="pc" /></td>
</tr>

<tr>
<th>Division</th>
<td>:</td>
<td>
<select name="div">

<option value="MU">Mumbai</option>
<option value="AU">Nanded</option>
<option value="NG">Nagpur</option>
<option value="NS">Nashik</option>
<option value="PU">Pune</option>

</select></td>
</tr>

<tr>
<th>District</th>
<td>:</td>
<td><select name="dis">

<option value="ah">ahmednagar</option>
<option value="ak">akola</option>
<option value="am">amravati</option>
<option value="au">aurangabad</option>
<option value="bi">beed</option>
<option value="bh">bhandara</option>
<option value="bu">buldhana</option>
<option value="ch">chandrapur</option>
<option value="dh">dhule</option>
<option value="ga">gadchiroli</option>
<option value="go">gondia</option>
<option value="hi">hingoli</option>
<option value="jg">jalgaon</option>
<option value="jn">jalna</option>
<option value="ko">kolhapur</option>
<option value="la">latur</option>
<option value="mc">mumbai city</option>
<option value="mu">mumbai suburban</option>
<option value="ng">nagpur</option>
<option value="nd">nanded</option>
<option value="nb">nandurbar</option>
<option value="ns">nashik</option>
<option value="os">osmanabad</option>
<option value="pa">parbhani</option>
<option value="pu">pune</option>
<option value="rg">raigad</option>
<option value="rt">ratnagiri</option>
<option value="sn">sangli</option>
<option value="st">satara</option>
<option value="si">sindhudurg</option>
<option value="so">solapur</option>
<option value="th">thane</option>
<option value="wr">wardha</option>
<option value="as">washim</option>
<option value="ytl">yavatmal</option>
<option value="pl">palghar</option>

</select></td>
</tr>

</table>
</fieldset>

<br>
<fieldset>
<legend>Marks</legend>
Enter Your University Marks:-
<table bgcolor="white">

<tr>
<th>Foundation Course</th>
<td>:</td>
<td><input type="number" name="fc"/></td>
</tr>

<tr>
<th>Chemistry Theory</th>
<td>:</td>
<td><input type="number" name="ct" /></td>
</tr>

<tr>
<th>Physics Theory</th>
<td>:</td>
<td><input type="number" name="pt" /></td>
</tr>

<tr>
<th>Physics Practical</th>
<td>:</td>
<td><input type="number" name="pp" /></td>
</tr>

<tr>
<th>Botany Theory</th>
<td>:</td>
<td><input type="number" name="Bt" /></td>
</tr>

<tr>
<th>Botany Practical</th>
<td>:</td>
<td><input type="number" name="Bp" /></td>

</tr>
</tr>

</table>
</fieldset>


<br>

<fieldset>
<legend>REQUIRED</legend>
<table>
<tr>
<th>Seat No.</th>
<td>:</td>
<td><input type="number" name="Sn"></th>
</tr>

<tr>
<th>Examination:</th>
<td>:</td>
<td><input type="number" name="Ex"></th>
</tr>
</table>
</fieldset>



<input type="submit"  value="Submit" name="submit"/>
<input type="submit"  value="Display" name="display"/>
<input type="reset" name="reset" value="reset"/>
</form>
</div>
</body>
</html>
