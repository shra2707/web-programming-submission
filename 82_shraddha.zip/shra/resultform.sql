-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2017 at 09:38 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `resultform`
--

-- --------------------------------------------------------

--
-- Table structure for table `addressdetails`
--

CREATE TABLE IF NOT EXISTS `addressdetails` (
  `Address` varchar(50) NOT NULL,
  `Pincode` int(10) NOT NULL,
  `Division` varchar(20) NOT NULL,
  `District` varchar(20) NOT NULL,
  `Nationality` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addressdetails`
--

INSERT INTO `addressdetails` (`Address`, `Pincode`, `Division`, `District`, `Nationality`) VALUES
('andheri', 865974, 'MU', 'ah', 'ind');

-- --------------------------------------------------------

--
-- Table structure for table `collegedetails`
--

CREATE TABLE IF NOT EXISTS `collegedetails` (
  `Nameofcollege` varchar(20) NOT NULL,
  `Collegeaddress` varchar(50) NOT NULL,
  `Pincode` int(10) NOT NULL,
  `Division` varchar(20) NOT NULL,
  `District` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collegedetails`
--

INSERT INTO `collegedetails` (`Nameofcollege`, `Collegeaddress`, `Pincode`, `Division`, `District`) VALUES
('dbit', 'kurla', 865974, 'MU', 'ah');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE IF NOT EXISTS `marks` (
  `FoundationCourse` int(4) NOT NULL,
  `ChemistryTheory` int(4) NOT NULL,
  `PhysicsTheory` int(4) NOT NULL,
  `Physicspractical` int(4) NOT NULL,
  `BotanyTheory` int(4) NOT NULL,
  `Botanypractical` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`FoundationCourse`, `ChemistryTheory`, `PhysicsTheory`, `Physicspractical`, `BotanyTheory`, `Botanypractical`) VALUES
(54, 45, 54, 54, 45, 45);

-- --------------------------------------------------------

--
-- Table structure for table `personalinformation`
--

CREATE TABLE IF NOT EXISTS `personalinformation` (
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `mothersname` varchar(20) NOT NULL,
  `contactno` bigint(10) NOT NULL,
  `emailid` varchar(20) NOT NULL,
  `gender` varchar(8) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personalinformation`
--

INSERT INTO `personalinformation` (`firstname`, `middlename`, `lastname`, `mothersname`, `contactno`, `emailid`, `gender`, `dob`) VALUES
('Shraddha', 'Vilas', 'Sawant', 'Vinaya', 985687412, 'shra@gmail.com', 'f', '2017-04-14');

-- --------------------------------------------------------

--
-- Table structure for table `required`
--

CREATE TABLE IF NOT EXISTS `required` (
  `Seatno` int(8) NOT NULL,
  `Examination` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `required`
--

INSERT INTO `required` (`Seatno`, `Examination`) VALUES
(89756, 85426);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
